import React, { useState } from "react";

export default function Home() {
  const [input, setInput] = useState("");
  const [resultado, setResultado] = useState(null);
  const [loading, setLoading] = useState(false);

  const verificar = () => {
    setLoading(true);
    setResultado(null);

    setTimeout(() => {
      const resultadosPosibles = [
        { estado: "Verdadero", color: "text-green-500" },
        { estado: "Falso", color: "text-red-500" },
        { estado: "Incompleto", color: "text-yellow-500" }
      ];
      const resultadoAleatorio =
        resultadosPosibles[Math.floor(Math.random() * resultadosPosibles.length)];

      setResultado(resultadoAleatorio);
      setLoading(false);
    }, 2000);
  };

  return (
    <main className="min-h-screen bg-zinc-900 text-white flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl font-bold mb-6 text-center">Verifica la Verdad</h1>
      <div className="w-full max-w-xl flex flex-col gap-4">
        <input
          type="text"
          placeholder="Escribe una afirmación para verificar..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="p-3 rounded-lg bg-zinc-800 border border-zinc-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={verificar}
          disabled={loading || !input}
          className="bg-blue-600 hover:bg-blue-700 transition rounded-lg py-2 font-semibold disabled:opacity-50"
        >
          {loading ? "Verificando..." : "Verificar"}
        </button>
        {resultado && (
          <div className={`mt-4 text-center text-2xl font-bold ${resultado.color}`}>
            Resultado: {resultado.estado}
          </div>
        )}
      </div>
      <footer className="mt-10 text-zinc-500 text-sm">
        © 2025 Verifica La Verdad. Proyecto simulado.
      </footer>
    </main>
  );
}
